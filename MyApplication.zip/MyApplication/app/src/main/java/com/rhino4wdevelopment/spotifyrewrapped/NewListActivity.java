package com.rhino4wdevelopment.spotifyrewrapped;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
//import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class NewListActivity extends AppCompatActivity {

    String authResponse;
    private static final int REQUEST_CODE = 1337;
    private static final String REDIRECT_URI = "https://myapp.org/callback";
    private static final String CLIENT_ID = "060a71f7ab7c43c283c27362e5446820";
    private static final String CLIENT_SECRET = "ef5448182a1243c28c20b10148b11a70";
    private static final String TAG = "SpotifyAuth";
    EditText title_edittext;

    private RadioGroup radioGroup;
    private RadioButton radioBlacklist, radioWhitelist;
    private EditText editText;
    private Button buttonSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_list);

        Intent oldIntent = this.getIntent();
        authResponse = oldIntent.getStringExtra("authResponse");

        radioGroup = findViewById(R.id.radioGroup);
        radioBlacklist = findViewById(R.id.radioBlacklist);
        radioWhitelist = findViewById(R.id.radioWhitelist);
        editText = findViewById(R.id.editText);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        title_edittext = findViewById(R.id.edittext_title);

        ColorStateList colorStateList = new ColorStateList(
                new int[][] {
                        new int[] { android.R.attr.state_checked }, // Checked state
                        new int[] { -android.R.attr.state_checked } // Unchecked state
                },
                new int[] {
                        Color.parseColor("#25d765"), // Color when checked
                        Color.parseColor("#9E9E9E")  // Color when unchecked
                }
        );
        radioWhitelist.setButtonTintList(colorStateList);
        radioBlacklist.setButtonTintList(colorStateList);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exchangeCodeForToken(authResponse);
            }
        });
    }



    private void exchangeCodeForToken(String code) {
        OkHttpClient client = new OkHttpClient();

        RequestBody formBody = new FormBody.Builder()
                .add("grant_type", "authorization_code")
                .add("code", code)
                .add("redirect_uri", REDIRECT_URI)
                .add("client_id", CLIENT_ID)
                .add("client_secret", CLIENT_SECRET)
                .build();

        Request request = new Request.Builder()
                .url("https://accounts.spotify.com/api/token")
                .post(formBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                //Log.e(TAG, "Token exchange failed: " + e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        String responseBody = Objects.requireNonNull(response.body()).string();
                        JSONObject jsonObject = new JSONObject(responseBody);
                        String accessToken = jsonObject.getString("access_token");

                        //Log.d(TAG, "Access token: " + accessToken);
                        fetchTopTracks(accessToken);
                    } catch (Exception e) {
                        //Log.e(TAG, "Failed to parse token response: " + e.getMessage());
                    }
                } else {
                    //Log.e(TAG, "Token exchange failed: " + response.message());
                }
            }
        });
    }

    private void fetchTopTracks(String accessToken) {
        OkHttpClient client = new OkHttpClient();
        ArrayList<SongEntry> songEntries = new ArrayList<>();
        int limit = 50;
        int maxTracks = 10000; // Total number of tracks you want

        // Use an array to keep track of fetched tracks since arrays are mutable
        final int[] fetchedTracks = {0};

        fetchTracksRecursive(client, accessToken, 0, limit, maxTracks, fetchedTracks, songEntries);
    }

    private void fetchTracksRecursive(OkHttpClient client, String accessToken, int offset, int limit, int maxTracks, int[] fetchedTracks, ArrayList<SongEntry> songEntries) {
        Request request = new Request.Builder()
                .url("https://api.spotify.com/v1/me/top/tracks?limit=" + limit + "&offset=" + offset + "&time_range=medium_term")
                .addHeader("Authorization", "Bearer " + accessToken)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                // Log error if needed
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        String responseBody = Objects.requireNonNull(response.body()).string();
                        JSONObject jsonObject = new JSONObject(responseBody);
                        JSONArray items = jsonObject.getJSONArray("items");

                        // Exit recursion if no items are returned
                        if (items.length() == 0) {
                            handleAllTracksFetched(songEntries);
                            return;
                        }

                        // Process the items and filter songs
                        String inputText = editText.getText().toString();
                        String[] rows = inputText.split("\\r?\\n"); // Splits by newlines
                        ArrayList<String> inputList = new ArrayList<>(Arrays.asList(rows));
                        boolean isWhitelist = radioWhitelist.isChecked();

                        for (int i = 0; i < items.length(); i++) {
                            JSONObject track = items.getJSONObject(i);
                            String trackName = track.getString("name");

                            // Extract artist names
                            JSONArray artistsArray = track.getJSONArray("artists");
                            ArrayList<String> artistList = new ArrayList<>();
                            for (int j = 0; j < artistsArray.length(); j++) {
                                artistList.add(artistsArray.getJSONObject(j).getString("name"));
                            }

                            // Determine if the song meets the filter condition
                            boolean matches = false;
                            for (String artist : artistList) {
                                if (inputList.contains(artist)) {
                                    matches = true;
                                    break;
                                }
                            }

                            // Apply the filter: whitelist or blacklist
                            if ((isWhitelist && matches) || (!isWhitelist && !matches)) {
                                // Extract track ID and album image
                                String trackId = track.getString("id");
                                JSONObject album = track.getJSONObject("album");
                                JSONArray imagesArray = album.getJSONArray("images");
                                String imageUrl = imagesArray.length() > 0 ? imagesArray.getJSONObject(0).getString("url") : "";

                                // Create a SongEntry and add it to the list
                                SongEntry songEntry = new SongEntry(trackName, artistList, trackId, imageUrl);
                                songEntries.add(songEntry);

                                // Stop fetching if 50 songs are collected
                                if (songEntries.size() >= 50) {
                                    handleAllTracksFetched(songEntries);
                                    return;
                                }
                            }
                        }

                        fetchedTracks[0] += items.length();

                        // Check if we need to fetch more tracks
                        if (items.length() == limit && fetchedTracks[0] < maxTracks) {
                            fetchTracksRecursive(client, accessToken, offset + limit, limit, maxTracks, fetchedTracks, songEntries);
                        } else {
                            // All tracks are fetched or the limit is reached
                            handleAllTracksFetched(songEntries);
                        }
                    } catch (Exception e) {
                        // Handle exception
                    }
                } else {
                    // Handle API response error
                }
            }
        });
    }

    private void handleAllTracksFetched(ArrayList<SongEntry> songEntries) {
        // Log or process the fetched tracks
        Intent resultIntent = new Intent();
        resultIntent.putParcelableArrayListExtra("MyListData", songEntries);
        resultIntent.putExtra("title", title_edittext.getText().toString());
        setResult(RESULT_OK, resultIntent);
        finish();
    }


}
