package com.rhino4wdevelopment.spotifyrewrapped;

import java.util.ArrayList;

public class MyDataSet {

    public int id;
    ArrayList<SongEntry> list;
    String text;

    /** @noinspection StringConcatenationInLoop*/
    public MyDataSet(ArrayList<SongEntry> list, int id, String title){
        this.id = id;
        this.list = list;

        if(title!=null){
            text=title;
        }
        else {
            text = "";
            int min = Math.min(list.size(), 3);
            for (int i = 0; i < min; i++) {
                text += list.get(i).getTitle();
                if (i != min - 1) {
                    text += ", ";
                }
            }
        }
    }

    public int getId(){
        return this.id;
    }
    public ArrayList<SongEntry> getList(){
        return this.list;
    }
    public String getText(){
        return this.text;
    }
}
