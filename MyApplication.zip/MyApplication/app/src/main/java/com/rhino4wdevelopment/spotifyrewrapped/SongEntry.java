package com.rhino4wdevelopment.spotifyrewrapped;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class SongEntry implements Parcelable {
    private String title;
    private ArrayList<String> artistList;
    private String id; // Spotify track ID
    private String image; // URL for the track image

    public SongEntry() {
        // Default constructor
    }

    public SongEntry(String title, ArrayList<String> artistList, String id, String image) {
        this.title = title;
        this.artistList = artistList;
        this.id = id;
        this.image = image;
    }

    protected SongEntry(Parcel in) {
        title = in.readString();
        artistList = in.createStringArrayList();
        id = in.readString();
        image = in.readString();
    }

    public static final Creator<SongEntry> CREATOR = new Creator<SongEntry>() {
        @Override
        public SongEntry createFromParcel(Parcel in) {
            return new SongEntry(in);
        }

        @Override
        public SongEntry[] newArray(int size) {
            return new SongEntry[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ArrayList<String> getArtistList() {
        return artistList;
    }

    public void setArtistList(ArrayList<String> artistList) {
        this.artistList = artistList;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeStringList(artistList);
        dest.writeString(id);
        dest.writeString(image);
    }
}

