package com.rhino4wdevelopment.spotifyrewrapped;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
//import android.util.Log;

import androidx.annotation.NonNull;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SpotifyPlaylistCreator {

    private static final String REDIRECT_URI = "https://myapp.org/callback";
    private static final String CLIENT_ID = "060a71f7ab7c43c283c27362e5446820";
    private static final String CLIENT_SECRET = "ef5448182a1243c28c20b10148b11a70";

    private static final String TAG = "SpotifyPlaylistCreator";

    public static void createPlaylist(String authToken, String title, ArrayList<SongEntry> songList, Context context) {
        new AsyncTask<Void, Void, Boolean>() {

            @Override
            protected Boolean doInBackground(Void... voids) {
                try {
                    // Step 1: Get User ID
                    String userId = getUserId(authToken);
                    if (userId == null) {
                      //  Log.e(TAG, "Failed to fetch user ID");
                        return false;
                    }

                    // Step 2: Create Playlist
                    String playlistId = createSpotifyPlaylist(authToken, userId, title);
                    if (playlistId == null) {
                      //  Log.e(TAG, "Failed to create playlist");
                        return false;
                    }

                    // Step 3: Add Tracks to Playlist
                    ArrayList<String> trackUris = new ArrayList<>();
                    for (SongEntry song : songList) {
                        trackUris.add("spotify:track:" + song.getId());
                    }
                    boolean success = addTracksToPlaylist(authToken, playlistId, trackUris, context);
                    return success;
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
            }

            @Override
            protected void onPostExecute(Boolean success) {
                // Show the confirmation dialog on the UI thread
                if (success) {
                    new AlertDialog.Builder(context)
                            .setTitle("Playlist Created")
                            .setMessage("Your playlist has been successfully created.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    // Finish the activity after the user clicks OK.
                                    if (context instanceof Activity) {
                                        ((Activity) context).finish();
                                    }
                                }
                            })
                            .setCancelable(false)
                            .show();
                } else {
                    new AlertDialog.Builder(context)
                            .setTitle("Error")
                            .setMessage("There was an error creating your playlist. Please try again.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    if (context instanceof Activity) {
                                        ((Activity) context).finish();
                                    }
                                }
                            })
                            .setCancelable(false)
                            .show();
                }
            }
        }.execute();
    }

    private static String getUserId(String authToken) throws Exception {
        URL url = new URL("https://api.spotify.com/v1/me");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Authorization", "Bearer " + authToken);

        int responseCode = connection.getResponseCode();
        //Log.d(TAG, "User ID Response Code: " + responseCode);

        if (responseCode == 200) {
            String response = Utils.readStream(connection.getInputStream());
            //Log.d(TAG, "Response: " + response);
            JSONObject jsonResponse = new JSONObject(response);
            return jsonResponse.getString("id");
        } else {
            String errorResponse = Utils.readStream(connection.getErrorStream());
            //Log.e(TAG, "Error Response: " + errorResponse);
        }
        return null;
    }


    private static String createSpotifyPlaylist(String authToken, String userId, String title) throws Exception {
        URL url = new URL("https://api.spotify.com/v1/users/" + userId + "/playlists");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Authorization", "Bearer " + authToken);
        connection.setRequestProperty("Content-Type", "application/json");

        JSONObject body = new JSONObject();
        body.put("name", title);
        body.put("description", "Generated by ReWrapped");
        body.put("public", false);

        OutputStream os = connection.getOutputStream();
        os.write(body.toString().getBytes());
        os.close();

        if (connection.getResponseCode() == 201) {
            String response = Utils.readStream(connection.getInputStream());
            JSONObject jsonResponse = new JSONObject(response);
            //Log.d("CreatePlaylist","Success");
            return jsonResponse.getString("id");
        }
        if (connection.getResponseCode() != 201) {
            //Log.e("CreatePlaylist", "Response Code: " + connection.getResponseCode());
            //Log.e("CreatePlaylist", "Response Message: " + connection.getResponseMessage());
            //Log.e("CreatePlaylist", "Error Stream: " + Utils.readStream(connection.getErrorStream()));
            return null;
        }
        return null;
    }

    private static boolean addTracksToPlaylist(String authToken, String playlistId, ArrayList<String> trackUris, Context context) throws Exception {
        URL url = new URL("https://api.spotify.com/v1/playlists/" + playlistId + "/tracks");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Authorization", "Bearer " + authToken);
        connection.setRequestProperty("Content-Type", "application/json");

        JSONObject body = new JSONObject();
        body.put("uris", new JSONArray(trackUris));

        OutputStream os = connection.getOutputStream();
        os.write(body.toString().getBytes());
        os.close();

        int responseCode = connection.getResponseCode();
        //Log.d(TAG, "Add Tracks Response Code: " + responseCode);

        if (responseCode == 201) {
            //Log.d(TAG, "Tracks added successfully.");

            return true;
        } else {
            //Log.e(TAG, "Failed to add tracks. Response Code: " + responseCode);
            //Log.e(TAG, "Error Stream: " + Utils.readStream(connection.getErrorStream()));
            return false;
        }
    }


    static void exchangeCodeForToken(String code, String title,ArrayList<SongEntry> songList, Context context) {
        OkHttpClient client = new OkHttpClient();

        RequestBody formBody = new FormBody.Builder()
                .add("grant_type", "authorization_code")
                .add("code", code)
                .add("redirect_uri", REDIRECT_URI)
                .add("client_id", CLIENT_ID)
                .add("client_secret", CLIENT_SECRET)
                .build();

        Request request = new Request.Builder()
                .url("https://accounts.spotify.com/api/token")
                .post(formBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                //Log.e(TAG, "Token exchange failed: " + e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        String responseBody = Objects.requireNonNull(response.body()).string();
                        JSONObject jsonObject = new JSONObject(responseBody);
                        String accessToken = jsonObject.getString("access_token");

                        //Log.d(TAG, "Access token: " + accessToken);
                        SpotifyPlaylistCreator.createPlaylist(accessToken,title,songList, context);
                    } catch (Exception e) {
                        //Log.e(TAG, "Failed to parse token response: " + e.getMessage());
                    }
                } else {
                    //Log.e(TAG, "Token exchange failed: " + response.message());
                }
            }
        });
    }

}
