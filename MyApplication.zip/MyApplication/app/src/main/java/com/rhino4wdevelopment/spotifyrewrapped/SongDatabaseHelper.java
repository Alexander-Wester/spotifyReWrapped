package com.rhino4wdevelopment.spotifyrewrapped;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class SongDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "songs.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_NAME = "song_table";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITLE = "title"; // New column for title
    private static final String COLUMN_SONGS = "songs"; // JSON String

    private Gson gson;

    public SongDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        gson = new Gson();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TITLE + " TEXT NOT NULL, " + // Add title column
                COLUMN_SONGS + " TEXT NOT NULL)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COLUMN_TITLE + " TEXT NOT NULL DEFAULT ''");
        }
    }

    // Insert a row with an ArrayList<SongEntry> and title
    public boolean insertSongs(String title, ArrayList<SongEntry> songEntries) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        String json = gson.toJson(songEntries); // Convert the list to JSON
        values.put(COLUMN_TITLE, title); // Add title
        values.put(COLUMN_SONGS, json);

        long result = db.insert(TABLE_NAME, null, values);
        return result != -1; // If result is -1, insertion failed
    }

    // Get all rows from the database
    public ArrayList<SongEntry> getSongsById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, new String[]{COLUMN_SONGS},
                COLUMN_ID + "=?", new String[]{String.valueOf(id)},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") String json = cursor.getString(cursor.getColumnIndex(COLUMN_SONGS));
            cursor.close();

            Type type = new TypeToken<ArrayList<SongEntry>>() {}.getType();
            return gson.fromJson(json, type); // Convert JSON back to ArrayList<SongEntry>
        }

        return null; // Return null if no matching ID is found
    }

    // Delete a row by ID
    public boolean deleteRow(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        return rowsDeleted > 0;
    }

    // Get all entries with titles
    public ArrayList<MyDataSet> getAllEntries() {
        ArrayList<MyDataSet> dataSetList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID));
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(COLUMN_TITLE));
                @SuppressLint("Range") String json = cursor.getString(cursor.getColumnIndex(COLUMN_SONGS));

                // Convert the JSON string back into an ArrayList<SongEntry> using Gson
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<SongEntry>>() {}.getType();
                ArrayList<SongEntry> songEntries = gson.fromJson(json, listType);

                // Create a MyDataSet object and add it to the list
                MyDataSet dataSet = new MyDataSet(songEntries, id, title); // Include title in MyDataSet
                dataSetList.add(dataSet);
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }

        return dataSetList;
    }
}

