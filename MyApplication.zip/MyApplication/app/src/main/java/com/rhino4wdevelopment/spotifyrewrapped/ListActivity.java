package com.rhino4wdevelopment.spotifyrewrapped;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;

import android.os.Bundle;


import android.view.View;

import androidx.activity.result.ActivityResultLauncher; // For launching activities
import androidx.activity.result.contract.ActivityResultContracts; // For result contracts

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {

    String authResponse;
    SongDatabaseHelper dbHelper;

    ArrayList<MyDataSet> dataSets = new ArrayList<>();

    MyAdapter adapter;
    RecyclerView recyclerView;
    ActivityResultLauncher<Intent> activityResultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_activity);

        dbHelper = new SongDatabaseHelper(this);

        Intent oldIntent = this.getIntent();
        authResponse = oldIntent.getStringExtra("response");

        recyclerView = findViewById(R.id.recyler_view);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        ArrayList<MyDataSet> dataList = dbHelper.getAllEntries();
        adapter = new MyAdapter(dataList, this, position -> {
            // Start ViewListActivity when a card is clicked
            Intent intent = new Intent(ListActivity.this, ViewListActivity.class);
            intent.putExtra("list", dataList.get(position).getList());
            intent.putExtra("title",dataList.get(position).getText());
            intent.putExtra("authResponse",authResponse);
            //Log.d("newActivity","Made it to putExtra");

            myListActivityLauncher2.launch(intent);
        });
        recyclerView.setAdapter(adapter);



        AppCompatButton startNewButton = findViewById(R.id.startnewButton);

        startNewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListActivity.this, NewListActivity.class);
                intent.putExtra("authResponse",authResponse);
                myListActivityLauncher.launch(intent);
            }
        });
    }
    private final ActivityResultLauncher<Intent> myListActivityLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null) {
                        ArrayList<SongEntry> myList = data.getParcelableArrayListExtra("MyListData");
                        String title = data.getStringExtra("title");

                        boolean isInserted = dbHelper.insertSongs(title,myList);
                        if (isInserted) {
                            //Log.d("Database", "Data inserted successfully!");
                            refreshRecyclerView();
                        } else {
                            //Log.d("Database", "Failed to insert data.");
                        }
                    }
                }
            }
    );
    private final ActivityResultLauncher<Intent> myListActivityLauncher2 = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    //Log.d("viewList","Success");
                }
            }
    );

    private void refreshRecyclerView() {
        // Fetch the latest data from the database
        ArrayList<MyDataSet> updatedDataList = dbHelper.getAllEntries();

        // Update the adapter's data
        adapter.updateData(updatedDataList);

        // Notify the adapter that the data has changed
        adapter.notifyDataSetChanged();
    }
}