package com.rhino4wdevelopment.spotifyrewrapped;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
//import android.util.Log;
import android.util.TypedValue;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ViewListActivity extends AppCompatActivity {
    Button btn_back;
    Button btn_make_new;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_list);
        btn_back = findViewById(R.id.btn_back);
        btn_make_new = findViewById(R.id.btn_make_playlist);

        Intent oldIntent = this.getIntent();
        ArrayList<SongEntry> myList = oldIntent.getParcelableArrayListExtra("list");
        String auth = oldIntent.getStringExtra("authResponse");
        String title = oldIntent.getStringExtra("title");

        LinearLayout container = findViewById(R.id.linear_container);

        displaySongEntries(myList, container);

        btn_back.setOnClickListener(view -> {
            // Finish this activity and return to ListActivity
            finish();
        });
        btn_make_new.setOnClickListener(view -> {
            Intent intent = new Intent(ViewListActivity.this, CreatePlaylistActivity.class);
            intent.putExtra("list", myList);
            intent.putExtra("authResponse",auth);
            intent.putExtra("title",title);
            myListActivityLauncher2.launch(intent);
        });
    }

    private void displaySongEntries(ArrayList<SongEntry> songEntries, LinearLayout container) {
        for (SongEntry entry : songEntries) {
            // Create a horizontal LinearLayout for each song entry
            LinearLayout songLayout = new LinearLayout(this);
            songLayout.setOrientation(LinearLayout.HORIZONTAL);
            songLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            songLayout.setPadding(0, 16, 0, 16); // Add some padding around each song

            // Create and set up an ImageView
            ImageView imageView = new ImageView(this);
            String imageUrl = entry.getImage();
            int imageSize = (int) getResources().getDisplayMetrics().density * 80; // 64dp size
            LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(imageSize, imageSize);
            imageView.setLayoutParams(imageParams);

            if (imageUrl != null && !imageUrl.isEmpty()) {
                Picasso.get().load(imageUrl).into(imageView);
            } else {
                imageView.setImageResource(R.drawable.green_question_mark); // Default image
            }

            // Create a LinearLayout for the title and artists TextViews
            LinearLayout textLayout = new LinearLayout(this);
            textLayout.setOrientation(LinearLayout.VERTICAL);
            textLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            textLayout.setPadding(16, 0, 0, 0); // Space between image and text

            // Create and set up a TextView for the title
            TextView titleTextView = new TextView(this);
            String title = entry.getTitle();
            titleTextView.setText(title);
            titleTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); // Set title text size
            titleTextView.setTextColor(Color.WHITE); // Set title text color to white
            textLayout.addView(titleTextView);

// Create and set up a TextView for the artists
            TextView artistsTextView = new TextView(this);
            ArrayList<String> artists = entry.getArtistList();
            String artistList = String.join(", ", artists);
            artistsTextView.setText("by: " + artistList);
            artistsTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14); // Set artist text size
            artistsTextView.setTextColor(Color.parseColor("#B0B0B0")); // Set artist text color to light grey
            textLayout.addView(artistsTextView);


            // Add the ImageView and the TextLayout (title + artists) to the songLayout
            songLayout.addView(imageView);
            songLayout.addView(textLayout);

            // Add the songLayout to the container
            container.addView(songLayout);
        }
    }

    private final ActivityResultLauncher<Intent> myListActivityLauncher2 = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    //Log.d("viewList","Success");
                }
            }
    );

}
