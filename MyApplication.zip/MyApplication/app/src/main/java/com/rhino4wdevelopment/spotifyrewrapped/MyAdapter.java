package com.rhino4wdevelopment.spotifyrewrapped;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    ArrayList<MyDataSet> dataList;
    Context context;
    SongDatabaseHelper dbHelper;
    OnCardClickListener onCardClickListener;
    public MyAdapter(ArrayList<MyDataSet> data, Context context, OnCardClickListener onCardClickListener){
        this.dataList = data;
        this.context = context;
        this.dbHelper = new SongDatabaseHelper(context);
        this.onCardClickListener=onCardClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        MyDataSet data = dataList.get(position);
        holder.textView.setText(data.getText());

        holder.cardView.setOnClickListener(view -> {
            // Notify the listener with the clicked item
            if (this.onCardClickListener != null) {
                this.onCardClickListener.onCardClick(holder.getAdapterPosition());
            }
        });

        holder.btnDelete.setOnClickListener(view -> {
            int idToDelete = data.getId(); // Get the ID of the item to delete

            // Remove from the database
            boolean isDeleted = dbHelper.deleteRow(idToDelete);

            if (isDeleted) {
                // Remove from the RecyclerView list
                dataList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, dataList.size());

                Toast.makeText(context, "Card deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Error deleting card", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView textView;
        CardView cardView;
        Button btnDelete;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.tv_card);
            cardView = itemView.findViewById(R.id.card_view);
            btnDelete = itemView.findViewById(R.id.btn_delete);
        }
    }
    public interface OnCardClickListener {
        void onCardClick(int id);
    }

    public void updateData(ArrayList<MyDataSet> newDataList) {
        this.dataList = newDataList;
    }
}


