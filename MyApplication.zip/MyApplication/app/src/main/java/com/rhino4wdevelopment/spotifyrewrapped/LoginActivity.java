package com.rhino4wdevelopment.spotifyrewrapped;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Toast;
//import android.util.Log;

import com.spotify.sdk.android.auth.AuthorizationClient;
import com.spotify.sdk.android.auth.AuthorizationRequest;
import com.spotify.sdk.android.auth.AuthorizationResponse;

import java.io.IOException;
import java.util.Objects;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import org.json.JSONArray;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    private static final int REQUEST_CODE = 1337;
    private static final String REDIRECT_URI = "https://myapp.org/callback";
    private static final String CLIENT_ID = "060a71f7ab7c43c283c27362e5446820";
    private static final String CLIENT_SECRET = "ef5448182a1243c28c20b10148b11a70";
    private static final String TAG = "SpotifyAuth";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_login);

        AuthorizationRequest.Builder builder =
                new AuthorizationRequest.Builder(CLIENT_ID, AuthorizationResponse.Type.CODE, REDIRECT_URI);

        builder.setScopes(new String[]{
                "user-top-read",
                "playlist-modify-private",
                "playlist-modify-public",
                "user-read-private"
        });
        AuthorizationRequest request = builder.build();

        AuthorizationClient.openLoginActivity(this, REQUEST_CODE, request);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        if (requestCode == REQUEST_CODE) {
            AuthorizationResponse response = AuthorizationClient.getResponse(resultCode, intent);

            switch (response.getType()) {
                case CODE:
                    //Log.d(TAG, "Auth code: " + response.getCode());
                    Toast.makeText(getApplicationContext(), "Code", Toast.LENGTH_SHORT).show();

                    Intent newIntent = new Intent(LoginActivity.this,ListActivity.class);
                    newIntent.putExtra("response",(String)response.getCode());
                    startActivity(newIntent);


                    //exchangeCodeForToken(response.getCode());
                    break;
                case ERROR:
                    Toast.makeText(getApplicationContext(), "Error: " + response.getError(), Toast.LENGTH_SHORT).show();
                    break;
                default:
                    Toast.makeText(getApplicationContext(), "Cancelled?", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
