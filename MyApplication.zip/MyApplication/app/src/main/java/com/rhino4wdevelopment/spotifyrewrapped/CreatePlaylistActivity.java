package com.rhino4wdevelopment.spotifyrewrapped;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;


public class CreatePlaylistActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent oldIntent = this.getIntent();
        ArrayList<SongEntry> myList = oldIntent.getParcelableArrayListExtra("list");
        String auth = oldIntent.getStringExtra("authResponse");
        String title = oldIntent.getStringExtra("title");

        SpotifyPlaylistCreator.exchangeCodeForToken(auth, title, myList,this);

        //Log.d("CreatePlaylist","Before finish");

        //finish();
    }
}
